import Foundation

public protocol ValueObject: Equatable {}
