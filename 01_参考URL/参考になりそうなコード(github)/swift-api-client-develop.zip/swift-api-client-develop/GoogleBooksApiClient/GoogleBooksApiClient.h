#import <UIKit/UIKit.h>

//! Project version number for GoogleBooksApiClient.
FOUNDATION_EXPORT double GoogleBooksApiClientVersionNumber;

//! Project version string for GoogleBooksApiClient.
FOUNDATION_EXPORT const unsigned char GoogleBooksApiClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GoogleBooksApiClient/PublicHeader.h>


